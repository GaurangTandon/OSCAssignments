char** tokenizeCommands(char*, int*);
void execCommand(char* command);
void checkPending();