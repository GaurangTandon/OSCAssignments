#include "common.h"

robot** robots;
void* initRobot(void* rTemp);
void robotPrintMsg(int id, char* fmt, ...);