char* fileName;
char* commandHistory[20];
int storedCount;
void printHistory(int n);
void addNewCommand(char* command);
void retrieveStored();
void historySetup();