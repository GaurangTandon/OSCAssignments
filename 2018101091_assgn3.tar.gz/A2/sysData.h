#pragma once
char* getUser();
void printMachine();