#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int a;
    scanf("%d", &a);
    printf("%d", a + 1);
    return 0;
}