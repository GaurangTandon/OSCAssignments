# Assignment CSE

Roll 2018101091
This application was tried and tested on Ubuntu 18.04.2.
I assume that when you ask me to input file you are inputting a path to file and not to a directory.

If the path is dead, then I will give you error. File size can be as big as `open` syscall permits. 

Report any bugs at gaurang.tandon@students.iiit.ac.in. Thanks.
