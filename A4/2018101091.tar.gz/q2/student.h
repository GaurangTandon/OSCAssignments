#include "common.h"

student** students;
void* initStudent(void* stTemp);
void studentPrintMsg(int id, char* fmt, ...);