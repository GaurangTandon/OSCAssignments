void printPinfo();
char* getProcName(int pid);
char* getProcPath(char* pid);
char* getProcStatusString(char* pid);