#pragma once
void printWelcomeScreen();
void printPrompt();