#include "common.h"

table** tables;
void* initTable(void* tableTemp);
void tablePrintMsg(int id, char* fmt, ...);