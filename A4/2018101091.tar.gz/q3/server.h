#ifndef sevrer
#define sevrer
#include "common.h"

server** servers;

void* initServer(void* server);

void acceptPayment();

#endif